import { createSlice } from '@reduxjs/toolkit'

const movieSlice = createSlice({
    name: 'movie',
    initialState : {

    },
    reducers : {
        a : (state, action) => {
            console.log(state);
        }
    }
})

export const MovieReducerActions = movieSlice.actions;

export default movieSlice.reducer;